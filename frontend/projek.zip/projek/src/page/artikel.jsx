import Footer from "../components/footer";
import Navbar from "../components/navbar";

function Artikel() {
    return(
        <>
                <Navbar />
        <div>
            <section className="bg-dark-subtle h-100 p-2">
                <div>
                    <h2>Halaman Artikel</h2>
                </div>
                <div>
                    <h2>Selamat Datang</h2>
                </div>
            </section>
        </div>
        <Footer />
        </>
    )
}

export default Artikel